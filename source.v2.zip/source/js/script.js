console.log("Load script.js");

// Instantiating the global app object
var app = {};
